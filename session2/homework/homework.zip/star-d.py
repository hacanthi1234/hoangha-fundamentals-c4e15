for i in range(10):
    for i in range(10):
        print('*', end='')
    print()

    #same solution with sentence e
