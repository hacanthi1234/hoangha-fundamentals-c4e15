print("Hello", end="")
print(", my name", end="")
print(" is B-max")
