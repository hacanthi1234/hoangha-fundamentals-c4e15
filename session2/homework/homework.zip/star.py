for i in range(1):
    for i in range(40):
        print('*', end='')
    print()

#same with sentence b
