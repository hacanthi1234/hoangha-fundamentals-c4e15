from turtle import *

shape("turtle")
speed(0)

color("red")

for i in range(4):
    left(60)
    forward(50)
    left(60)
    forward(50)
    left(120)
    forward(50)
    left(60)
    forward(50)
    right(30)


mainloop()
